const path = require('path');
const { PrismaClient } = require('@prisma/client');

require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });
require('dotenv').config({ path: path.resolve(__dirname, '../../.env.migration'), override: true });

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing ${name} for PostgreSQL runtime`);
  return value;
}

function databaseUrl() {
  if (process.env.DATABASE_URL) return process.env.DATABASE_URL;
  const user = encodeURIComponent(required('PGUSER'));
  const password = encodeURIComponent(required('PGPASSWORD'));
  const host = required('PGHOST');
  const port = process.env.PGPORT || '5432';
  const database = encodeURIComponent(required('PGDATABASE'));
  const ssl = String(process.env.PGSSL || 'false').toLowerCase() === 'true' ? '?sslmode=require' : '';
  return `postgresql://${user}:${password}@${host}:${port}/${database}${ssl}`;
}

if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = databaseUrl();
}

const prisma = global.__buildmatePrisma || new PrismaClient();
if (process.env.NODE_ENV !== 'production') {
  global.__buildmatePrisma = prisma;
}

module.exports = { prisma };
